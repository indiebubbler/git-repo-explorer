export const FETCH_USERS_REQUEST = 'fetchUsersRequest'
export const FETCH_USERS_SUCCESS = 'fetchUsersSuccess'
export const FETCH_USERS_FAILURE = 'fetchUsersFailure'

export const FETCH_REPOS_REQUEST = 'fetchReposRequest'
export const FETCH_REPOS_SUCCESS = 'fetchReposSuccess'
export const FETCH_REPOS_FAILURE = 'fetchReposFailure'
export const CLEAR_REPOS = 'clearRepos'
