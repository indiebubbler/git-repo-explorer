// import * as actions from '../actions/actionTypes'

// export const searchUsers = text => ({
//     type: actions.SEARCH_USERS,
//     payload: text
// })

// export const usersLoaded = userList => ({
//     type: actions.USERS_LOADED,
//     payload: userList
// })

// export const reposLoaded = reposList => ({
//     type: actions.REPOS_LOADED,
//     payload: reposList
// })


// export function usersLoaded(users) {
//     return {
//         type: actions.USERS_LOADED,
//         payload: users
//     }
// }


